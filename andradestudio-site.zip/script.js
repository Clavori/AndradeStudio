const whatsappButton = document.querySelector("#whatsappButton");

whatsappButton?.addEventListener("click", () => {
  const form = whatsappButton.closest("form");
  const data = new FormData(form);
  const nome = data.get("nome")?.toString().trim() || "Cliente";
  const projeto = data.get("projeto")?.toString().trim() || "projeto digital";
  const mensagem = data.get("mensagem")?.toString().trim() || "Quero conversar sobre um projeto para minha empresa.";

  const texto = [
    `Olá, meu nome é ${nome}.`,
    `Tenho interesse em: ${projeto}.`,
    mensagem,
  ].join("\n");

  window.open(`https://wa.me/?text=${encodeURIComponent(texto)}`, "_blank", "noopener,noreferrer");
});

const revealTargets = document.querySelectorAll(
  ".service-card, .project-card, .metrics div, .testimonial-grid blockquote, .timeline article, .impact-strip div, .showcase-copy, .device-preview"
);

const revealObserver = new IntersectionObserver(
  (entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.classList.add("is-visible");
        revealObserver.unobserve(entry.target);
      }
    });
  },
  { threshold: 0.16 }
);

revealTargets.forEach((target) => {
  target.classList.add("reveal");
  revealObserver.observe(target);
});
